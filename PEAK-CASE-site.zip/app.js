
const cases = [
 {id:"royal",name:"Королевский",desc:"Только легендарные скины",price:299,img:"royal.jpg"},
 {id:"ice",name:"Ледяной Дракон",desc:"Скины, от которых мурашки",price:199,img:"ice.jpg",badge:"NEW"},
 {id:"aggressor",name:"Агрессор",desc:"Для настоящих бойцов",price:149,img:"aggressor.jpg"},
 {id:"phantom",name:"Фантом",desc:"Тайные скины и ножи",price:249,img:"phantom.jpg"},
 {id:"beach",name:"Пляжный Бунт",desc:"Солнце, море, скины",price:99,img:"beach.jpg"},
 {id:"space",name:"Космос",desc:"Открой свою галактику",price:179,img:"space.jpg"},
 {id:"operation",name:"Операция",desc:"Классика в новом свете",price:129,img:"operation.jpg"},
 {id:"inferno",name:"Инферно",desc:"Горячие скины ждут тебя",price:219,img:"inferno.jpg"},
 {id:"void",name:"Тёмный Пик",desc:"Редкость из глубины",price:349,img:"void.jpg"},
 {id:"neon",name:"Неон",desc:"Яркий дроп. Жёсткий стиль.",price:159,img:"neon.jpg"}
];
const app=document.querySelector("#app"), toast=document.querySelector("#toast");

function topbar(){return `<header class="topbar"><button class="menu-btn" onclick="openMenu()"><span class="burger"></span></button><div class="logo" onclick="go('home')">PEAK-CASE</div></header>`}
function nav(active){const items=[["home","⌂","Главная"],["profile","●","Профиль"],["upgrade","↑","Upgrade"],["contracts","◆","Контракты"],["history","◷","История"]];return `<nav class="bottom-nav">${items.map(x=>`<button class="nav-item ${active===x[0]?'active':''}" onclick="go('${x[0]}')"><span class="nav-icon">${x[1]}</span>${x[2]}</button>`).join("")}</nav>`}
function shell(content,active){app.innerHTML=`<div class="app">${topbar()}<main class="container">${content}</main>${nav(active)}<div id="drawer-bg" class="drawer-bg" onclick="closeMenu()"><aside class="drawer" onclick="event.stopPropagation()"><div class="drawer-head"><div class="drawer-title">Навигация</div><button class="close" onclick="closeMenu()">✕</button></div><div class="menu-list">
${[['home','⌂','Главная'],['profile','●','Профиль'],['upgrade','↑','Peak Upgrade'],['contracts','◆','Контракты'],['history','◷','История'],['cases','◈','Все кейсы']].map(x=>`<button class="menu-link" onclick="go('${x[0]}')"><span class="mi">${x[1]}</span>${x[2]}</button>`).join("")}</div></aside></div></div>`}
function home(){
 const cards=cases.map(c=>`<article class="card" onclick="go('case/${c.id}')">${c.badge?`<span class="badge">${c.badge}</span>`:""}<div class="card-img" style="background-image:url('assets/${c.img}')"></div><div class="card-body"><h3>${c.name}</h3><p>${c.desc}</p><div class="card-row"><span class="price">${c.price} ₽</span><span class="arrow">›</span></div></div></article>`).join("");
 shell(`<section class="hero"><div class="hero-glow"></div><div class="eyebrow">ОТКРЫВАЙ КЕЙСЫ</div><h1>КЕЙСЫ</h1><p>Лучшие кейсы скинов и ножей из<br>Counter-Strike 2</p></section><div class="section-title"><h2>Коллекция кейсов</h2><span>10 доступных</span></div><section class="grid">${cards}</section>`,"home")
}
function casePage(id){
 const c=cases.find(x=>x.id===id)||cases[0];
 shell(`<section class="page"><button class="back" onclick="go('home')">‹ Все кейсы</button><div class="case-head"><h1>${c.name}</h1><p>${c.desc} · ${c.price} ₽</p></div><div class="open-stage"><img class="case-large" src="assets/${c.img}"><div class="stage-label">ЗОНА БУДУЩЕЙ АНИМАЦИИ</div></div><div class="actions"><button class="action" onclick="fakeOpen('${c.name}')">Открыть</button><button class="action secondary" onclick="fakeOpen('${c.name}',true)">Открыть быстро</button></div><div class="info-grid"><div class="info"><b>?</b><span>ДРОПЫ</span></div><div class="info"><b>CS2</b><span>ПРЕДМЕТЫ</span></div><div class="info"><b>${c.price} ₽</b><span>ЦЕНА</span></div></div></section>`,"home")
}
function placeholder(title,icon,text,active){shell(`<section class="placeholder"><div class="placeholder-card"><div class="placeholder-icon">${icon}</div><h1>${title}</h1><p>${text}</p></div></section>`,active)}
function openMenu(){document.querySelector("#drawer-bg")?.classList.add("open")}
function closeMenu(){document.querySelector("#drawer-bg")?.classList.remove("open")}
function fakeOpen(name,fast=false){showToast(fast?`Быстрое открытие «${name}» — механика готовится`:`Открытие «${name}» — механика готовится`)}
function showToast(t){toast.textContent=t;toast.classList.add("show");clearTimeout(window.__t);window.__t=setTimeout(()=>toast.classList.remove("show"),2300)}
function go(route){
 closeMenu();
 history.pushState({route},"",route==="home"?"#home":"#"+route);
 render(route);
 window.scrollTo({top:0,behavior:"smooth"});
}
function render(route){
 if(!route||route==="home") return home();
 if(route.startsWith("case/")) return casePage(route.split("/")[1]);
 const map={
 profile:["Профиль","●","Здесь появится профиль пользователя, баланс, аватар и статистика.","profile"],
 upgrade:["Peak Upgrade","↑","Подготовленная зона для будущего Upgrade: выбор предмета, цели и результата.","upgrade"],
 contracts:["Контракты","◆","Здесь появится система контрактов и обмен нескольких предметов на один новый.","contracts"],
 history:["История","◷","Здесь будет отображаться история открытий, Upgrade, контрактов и других действий.","history"],
 cases:["Все кейсы","◈","Каталог кейсов уже доступен на главной странице. Здесь можно будет сделать отдельный расширенный каталог.","home"]
 };
 const x=map[route]||map.home; placeholder(x[0],x[1],x[2],x[3]);
}
window.addEventListener("popstate",()=>render(location.hash.slice(1)||"home"));
render(location.hash.slice(1)||"home");
